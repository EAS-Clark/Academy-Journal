export default {
    PORT: process.env.PORT,
    TARGET_URL: process.env.TARGET_URL
}