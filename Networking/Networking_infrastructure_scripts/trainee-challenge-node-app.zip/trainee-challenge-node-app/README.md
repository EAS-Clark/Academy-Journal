# trainee-challenge-node-app

### Pre reqs
Some configuration is required for the app to run. This is indicated when you first run the application. You need to configure Environment Variables for the applications port `PORT` and the target url `TARGET_URL` for the next app in the chain.

### Usage
```
$ npm install
$ npm start
```
